#ifndef PROCESSES_H
#define PROCESSES_H

void process_bus(int stops_count, int tb);
void process_skier(int skier_id, int stop_id, int tl, int bus_cap);

#endif
